#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void) {
    pid_t p = fork();

    if (p < 0) {
        perror("fork");
        return 1;
    }

    if (p == 0) {
        // Child branch
        printf("[Child] Work started. My PID: %d\n", (int)getpid());
        sleep(2); // Pause so the parent waiting can be observed
        printf("[Child] Work finished! Exiting now.\n");
        exit(0);
    } else {
        // Parent branch
        printf("[Parent] Child started. Now waiting for it to finish...\n");
        fflush(stdout);

        // wait(NULL) blocks until the child exits and returns its PID
        pid_t terminated_pid = wait(NULL);

        if (terminated_pid < 0) {
            perror("wait");
            return 1;
        }

        printf("[Parent] Child with PID %d has terminated!\n", (int)terminated_pid);
    }

    return 0;
}
