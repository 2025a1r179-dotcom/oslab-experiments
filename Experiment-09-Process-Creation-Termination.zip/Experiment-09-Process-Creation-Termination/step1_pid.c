#include <stdio.h>
#include <unistd.h>

int main(void) {
    // getpid() returns the PID of the currently running process
    printf("I am a simple process. My PID is: %d\n", (int)getpid());
    return 0;
}
