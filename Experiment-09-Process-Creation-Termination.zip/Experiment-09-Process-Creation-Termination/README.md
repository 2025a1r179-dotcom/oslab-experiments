# Experiment 9: Process Creation and Termination Using C

**Course:** COM-312 Operating System Lab  
**Institute:** Model Institute of Engineering & Technology (Autonomous)

## Aim
To write and execute C programs that retrieve a process ID (PID), create a child process using `fork()`, wait for the child to terminate, and display the terminated child's PID under Linux.

## Files
- `step1_pid.c` — retrieves and displays the current process ID using `getpid()`.
- `step2_fork.c` — creates a child process using `fork()` and demonstrates the different return values in parent and child.
- `process_creation_wait.c` — synchronizes the parent and child using `wait()` and displays the terminated child's PID.

## Requirements
- Linux or Ubuntu
- GCC compiler

## Compile and run

Open a terminal in this directory.

### Step 1: Get the current process ID
```bash
gcc step1_pid.c -o step1_pid
./step1_pid
```

Example output (the PID will vary):
```text
I am a simple process. My PID is: 3412
```

### Step 2: Create a child process with `fork()`
```bash
gcc step2_fork.c -o step2_fork
./step2_fork
```

Example output (the order and PIDs can vary):
```text
I am the PARENT process! fork() gave me child's PID: 3450
I am the CHILD process! My own PID: 3450
```

**Note:** The manual's sample output repeats the same PID on both lines. In an actual run, the parent line reports the child's PID and the child line reports its own PID, so these refer to the same child PID; the parent's own PID is not printed by this program. Output order can vary because the parent and child run concurrently.

### Step 3: Synchronize with `wait()`
```bash
gcc process_creation_wait.c -o exp9
./exp9
```

Example output (the PID will vary):
```text
[Parent] Child started. Now waiting for it to finish...
[Child] Work started. My PID: 3450
[Child] Work finished! Exiting now.
[Parent] Child with PID 3450 has terminated!
```

## Key concepts
- `getpid()` returns the PID of the currently running process.
- `fork()` creates a child process. It returns `0` in the child and the child's positive PID in the parent.
- `wait(NULL)` blocks the parent until a child terminates and returns the terminated child's PID.
- `sleep(2)` pauses the child for two seconds so the parent waiting can be observed.

## Result
The programs demonstrate PID retrieval, child process creation with `fork()`, and parent-child synchronization using `wait()`.

## Troubleshooting
- If `gcc` is missing on Ubuntu, install it with:
  ```bash
  sudo apt update
  sudo apt install build-essential
  ```
- If a command says a file does not exist, ensure your terminal is in this experiment's directory using `cd`.
