#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(void) {
    pid_t p = fork();

    if (p < 0) {
        perror("fork");
        return 1;
    }

    // From this point onward, both processes execute the same code
    if (p == 0) {
        // Only the child executes this branch
        printf("I am the CHILD process! My own PID: %d\n", (int)getpid());
    } else {
        // Only the parent executes this branch; p is the child's PID
        printf("I am the PARENT process! fork() gave me child's PID: %d\n", (int)p);
    }

    return 0;
}
